// framework.h
//
#pragma once

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN
#define _WIN32_WINNT _WIN32_WINNT_WIN10
#define WINVER _WIN32_WINNT_WIN10

////////////////////////////////////////////////////////////////////////////////////////////////////

#include <Windows.h>
