// resource.h
// use Resource.rc
//
#define IDI_ICON1                       101
#define IDR_MENU1                       102

#define IDM_NEW_WINDOW		40001
#define IDM_EXIT			40002
#define IDM_VIEW_HELP		40003
#define IDM_SEND_FEEDBACK	40004
#define IDM_ABOUT			40005

#define IDR_BUTTON			10001
#define IDR_EDIT			10002
