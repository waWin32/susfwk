// WinMain.c
//
#include "framework.h"
#include "WinMain.h"
#include "resource.h"

int _fltused = 1;

int main()
{
	SUS_CONSOLE_DEBUGGING();
	SUS_WINDOW wnd = susWindowSetup("Example", NULL);
	susWindowSetBounds(&wnd, (RECT) { 100, 100, 400, 380 });
	susWindowSetIcon(&wnd, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
	susWindowSetMenu(&wnd, MAKEINTRESOURCE(IDR_MENU1));
	susWindowSetHandler(&wnd, MainWndProc);
	susBuildWindow(&wnd);
	SUS_PRINTDL("The window has been created successfully!");
	susWindowSetVisible(&wnd, TRUE);
	ExitProcess(susWindowMainLoop());
}

// The main window handler
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_COMMAND: {
		switch (LOWORD(wParam))
		{
		case IDM_ABOUT: {
			MessageBoxW(hWnd,
				L"MyProgram\n"
				L"������: [0.0.1]\n"
				L"���� ������� : "__DATE__"\n"
				L"�����������: [������ susfwk]\n"
				L"MyProgram - ��� ������ ��� �������� �������� ���������� �� susfwk.\n"
				L"Copyright � 2025-2025 waWin32",
				L"About the program",
				MB_ICONINFORMATION
			);
		} break;
		case IDM_SEND_FEEDBACK: {
			ShellExecuteA(hWnd, "open", "https://t.me/waWin32", NULL, NULL, SW_SHOWNORMAL);
		} break;
		case IDM_VIEW_HELP: {
			ShellExecuteA(hWnd, "open", "https://dikiles.ru/vijivanie/orientirovanie/vyzhivanie-v-dikoj-prirode/", NULL, NULL, SW_SHOWNORMAL);
		} break;
		case IDM_NEW_WINDOW: {
			SUS_WINDOW wnd = susWindowSetup("Example 2", NULL);
			susWindowSetBounds(&wnd, (RECT) { 100, 100, 400, 380 });
			susWindowSetIcon(&wnd, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
			susWindowSetMenu(&wnd, MAKEINTRESOURCE(IDR_MENU1));
			susWindowSetHandler(&wnd, MainWndProc);
			susBuildWindow(&wnd);
			susWindowSetVisible(&wnd, TRUE);
		} break;
		case IDM_EXIT: {
			DestroyWindow(hWnd);
		} break;
		}
	} return 0;
	case WM_DESTROY: {
		PostQuitMessage(0);
	} return 0;
	default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
}


