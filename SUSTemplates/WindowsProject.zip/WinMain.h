// WinMain.h
//
#ifndef _WIN_MAIN_
#define _WIN_MAIN_

// The main window handler
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif /* !_WIN_MAIN_ */
