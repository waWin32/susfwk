// Main.c
//
#include "framework.h"

int _fltused = 1;

// Main frame handler
SUS_RESULT SUSAPI FrameHandler(SUS_WINDOW frame, SUS_WINMSG msg, SUS_PARAM param);
// Main panel handler
SUS_RESULT SUSAPI PanelHandler(SUS_WINDOW panel, SUS_WINMSG msg, SUS_PARAM param);

int main() {
	SUS_FRAME frame = susNewFrame(L"Application", (SUS_SIZE) { 800, 600 }, FrameHandler);
	if (!frame) sus_error(1);
	sus_exit(susWindowMainLoop());
}

// Window Data
typedef struct main_window {
	struct {
		CHAR dummy;
		// ...
	} data; // Data
	struct {
		CHAR dummy;
		// ...
	} wgs; // Widgets
	struct {
		CHAR dummy;
		// ...
	} res; // Resources
} MAIN_WINDOW_STRUCT, *MAIN_WINDOW;

// Main frame handler
SUS_RESULT SUSAPI FrameHandler(SUS_WINDOW frame, SUS_WINMSG msg, SUS_PARAM param)
{
	switch (msg)
	{
	case SUS_WINMSG_CREATE: {
		susWindowSetData(frame, sus_malloc(sizeof(MAIN_WINDOW_STRUCT)));
		SUS_ASSERT(susWindowGetData(frame));
		susWindowSetCloseOperation((SUS_FRAME)frame, SUS_WINDOW_EXIT_ON_CLOSE);
		SUS_WIDGET panel = susNewPanel(frame, PanelHandler);
		susWindowSetDoubleBuffer((SUS_WINDOW)panel, TRUE);
		susWindowSetBackground((SUS_WINDOW)panel, SUS_COLOR_MAGENTA);
		susWindowSetVisible(frame, TRUE);
	} return 0;
	case SUS_WINMSG_DESTROY: {
		sus_free((SUS_LPMEMORY)susWindowGetData(frame));
	} return 0;
	default: return 0;
	}
}
// Main panel handler
SUS_RESULT SUSAPI PanelHandler(SUS_WINDOW panel, SUS_WINMSG msg, SUS_PARAM param)
{
	MAIN_WINDOW window = susWindowGetData(panel);
	switch (msg)
	{
	case SUS_WINMSG_CREATE: {
		// Widget Placement
	} return 0;
	case SUS_WINMSG_PAINT: {
		SUS_GRAPHICS gr = (SUS_GRAPHICS)param;
		// Painting
	} return 0;
	default: return 0;
	}
}
