// Main.c
//
#include "framework.h"

int _fltused = 1;

int main()
{
	SUS_CONSOLE_DEBUGGING();

	sus_printf("Hello from console Application\n");

	ExitProcess(0);
}
