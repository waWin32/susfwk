// Main.c
//
#include "framework.h"

int _fltused = 1;

int main()
{
	sus_printf("Hello world");
	sus_exit(0);
}