// DllMain.c
//
#include "framework.h"

DWORD WINAPI MainThread(LPVOID hinstDLL)
{
    SUS_PRINTDL("Hello world!");
    ExitThread(0);
}

BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,
    DWORD fdwReason,
    LPVOID lpvReserved)
{
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hinstDLL);
        SUS_FILE hThr = susCreateThread(MainThread, hinstDLL, TRUE);
        if (!hThr) return FALSE;
        sus_fclose(hThr);
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}