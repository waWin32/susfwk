// DllMain.c
//
#include "framework.h"

DWORD WINAPI MainThread(LPVOID hinstDLL)
{
    SUS_LOGFILE_DEBUGGING(susCreateTempFileA("dlllog", ".log", 0, NULL));
    SUS_PRINTDL("Hello world!");
    SUS_LOGFILE_CLOSE(SUS_GET_DEBUG_OUT());
	ExitProcess(0);
}

BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,
    DWORD fdwReason,
    LPVOID lpvReserved)
{
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hinstDLL);
        SUS_FILE hThr = susCreateThread(MainThread, hinstDLL);
        if (!hThr) return FALSE;
        sus_fclose(hThr);
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}